package com.tweetapp.kafka;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.UsersDto;
@Service
public class Producer {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private KafkaTemplate<String, List<UsersDto>> kafkaTemplate;
	  String topicName="tweet";
	public void sendMessage(List<UsersDto> msg) {
		logger.info("sent message:"+msg);
		kafkaTemplate.send( topicName, msg);
//	   kafkaTemplate.send(topicName, msg);
	}   

}
