package com.tweetapp.kafka;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.UsersDto;

@Service
@Component
public class Consumer {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
//	@KafkaListener(topics = "tweet", groupId = "group-id")
//	public String listen(String message) {
//		logger.info("Received Messasge in group - group-id: " + message);
//		return "message received:"+message;
//	   
//	}
	 @KafkaListener(topics = "Users", groupId = "user", containerFactory = "kafkaListenerContainerFactory")
	    void listener(List<UsersDto> data) {
			logger.info("Received Messasge in group - group-id: ");
	        data.forEach(o-> System.out.println(o.getLoginId()+":"+o.getFirstName()));
	    }

}
