import CustomNavBar from './custom-nav-bar.container';

export default CustomNavBar
