import MyTweets from "./my-tweets.container";

export default MyTweets;