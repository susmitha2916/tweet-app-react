import AllUsers from "./all-users.container";

export default AllUsers;